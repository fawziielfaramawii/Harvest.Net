﻿using ef3.model;
using Microsoft.EntityFrameworkCore;

namespace ef3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            companycontext context = new companycontext();
            employee emp = new employee()
            {
                Name="nada",
                Salary=4000,
                departmentId=1

            };
            context.employees.Add(emp);
            context.SaveChanges();
            employee emp2 = new employee()
            {
                Name="malak",
                Salary=400,
                departmentId=1

            };
            context.employees.Add(emp2);
            context.SaveChanges();
            context.employees.Where(a => a.Id==1).ExecuteDelete();//donot need savechanges it go direct to db
        }
    }
}
