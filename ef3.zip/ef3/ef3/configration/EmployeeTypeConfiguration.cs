﻿using ef3.model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ef3.configration
{
    public class EmployeeTypeConfiguration : IEntityTypeConfiguration<employee>
    {
        public void Configure(EntityTypeBuilder<employee> builder)
        {
           // builder.HasKey(a => a.Id);
            builder.Property(a => a.Name)
                   .IsRequired()
                   .HasMaxLength(150)
                   .HasColumnName("Full name");
        }

        
    }
}
