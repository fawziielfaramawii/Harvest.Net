﻿using ef3.configration;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ef3.model
{
   public class companycontext:DbContext
    {
        //TrustServerCertificate=True
        // Encrypt = False 
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server = DESKTOP-8VCJTE7 ; Database = DBCompanyDay3 ; Integrated Security = True ; Encrypt = False ");
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            #region fluent API
            //fluent API
            //modelBuilder.Entity<employee>()
            //.Property(a => a.Name)
            //.IsRequired()
            //.HasMaxLength(150)
            //.HasColumnName("Full name"); 
            #endregion
            modelBuilder.Entity<project>()
                        .Property(a => a.Date)
                       // .HasDefaultValue(new DateTime().Date )
                        .HasDefaultValueSql("GETDATE()");
           // new EmployeeTypeConfiguration().Configure(modelBuilder.Entity<employee>());
            base.OnModelCreating(modelBuilder);
        }
        public DbSet<employee> employees { get; set; }
        public DbSet<department> departments { get; set; }
        public DbSet<project> projects { get; set; }
    }
}
