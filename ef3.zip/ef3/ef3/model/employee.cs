﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ef3.model
{
    [Table("Employee")]//change table name
    public class employee // child entity , dependent entity
    {
                       //data annotation
        //[Key]//PK
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]//identity
        //[Key,DatabaseGenerated(DatabaseGeneratedOption.Identity)]//one step
        //public int empId { get; set; }
        public  int Id { get; set; }
        //[Required,MaxLength(150)]//ont allow null , maxlength
        //[Column(TypeName ="fullname")]//to change column name
        public string Name { get; set; }
        public address address { get; set; }
        public double? Salary { get; set; }// ? => to make it allow null
        //[ForeignKey(nameof(deptid))]
        //public int deptid { get; set; }
        public int departmentId { get; set; }//هيفم لوحده
        public department department { get; set; }//one =>many(this one)//reference navigation property
    }
}
