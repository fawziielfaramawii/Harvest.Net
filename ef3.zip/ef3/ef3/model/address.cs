﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ef3.model
{
    public class address
    {
        public string street { get; set; }
        public string gov { get; set; }
        [Key]
        public int Empolyeeid { get; set; }
        public employee employee { get; set; }

    }
}
