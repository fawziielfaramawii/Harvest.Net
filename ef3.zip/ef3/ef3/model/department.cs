﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace ef3.model
{
    public class department//perent entity , principle entity
    {
        public int Id { get; set; }//principle key
        public string Name { get; set; }
        public string Location { get; set; }
        public List<employee> employees { get; set; }//many of relation (1=>many)//collection navigation property
    }
}
